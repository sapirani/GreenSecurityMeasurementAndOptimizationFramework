import random
import string

def generate_word(l):
    return "".join(random.choices(string.ascii_lowercase, k=l))

def write_to_file(name, n, l):
    with open(name, "w") as f:
        for _ in range(n):
            f.write(generate_word(l) + "\n")


n = 50 * 2**20
l = 5
f_name = "input_50_2_20.txt"

write_to_file(f_name, n, l)
print(f"{n} random words written to {f_name}")

