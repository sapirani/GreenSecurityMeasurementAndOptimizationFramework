import time

time.sleep(30)
