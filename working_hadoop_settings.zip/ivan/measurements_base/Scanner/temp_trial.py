import time

def loop_over():
	while(True):
		print("Hello")
		time.sleep(10)

if __name__ == "__main__":
	loop_over()
